# STRUKTUR DATA 2026

## Identitas
Nama:
NIM:
Program Studi:
Mata Kuliah: Struktur Data

---

## Deskripsi Repository
Repository ini berisi seluruh materi, latihan, tugas, dan final project mata kuliah Struktur Data.

---

## Aturan
- Minimal 5 commit per tugas
- Gunakan branch develop
- Sertakan README di setiap folder tugas
